#!/bin/bash

if [ "$1" = "-help" ]; then
    echo "Uso:"
    echo "$0 ORIGEN DESTINO"
    exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
    echo "Error: faltan parámetros."
    exit 1
fi

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino no existe."
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino no está montado como sistema de archivos."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

echo "Backup realizado correctamente."
