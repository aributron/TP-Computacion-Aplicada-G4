history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ping -c 4 8.8.8.8
cat /etc/resolv.conf
ping -c 4 8.8.8.8
vi /etc/apt/sources.list
apt update
apt install nano -y
nano --version
apt upgrade -y
apt full-upgrade -y
reboot
cat /etc/debian_version
nano /etc/apt/sources.list
apt update
apt upgrade -y
apt full-upgrade -y
reboot
scp clave_privada.txt root@192.168.1.45:/root/
scp clave_publica.pub root@192.168.1.45:/root/
mount | grep sf_
ls /media
ls /media/*
ls /mnt
lsmod | grep vbox
systemctl status ssh
ip a
su -
ip a
ip route
grep -E "PermitRootLogin|PasswordAuthentication|PubkeyAuthentication" /
ip a
ip route
apt install apache2 php libapache2-mod-php -y
systemctl enable apache2
systemctl start apache2
php -v
apache2 -v
ls -l /root/index.php
cp /root/index.php /var/www/html/
ls -l /var/www/html
systemctl restart apache2
systemctl status apache2
curl http://localhost
ls -l /var/www/html
mv /var/www/html/index.html /var/www/html/index.html.bak
cp /root/index.php /var/www/html/index.php
systemctl restart apache2
ls -l /var/www/html/
cat /var/www/html/index.php
php /var/www/html/index.php
tail -n 30 /var/log/apache2/error.log
apt install mariadb-server mariadb-client -y
systemctl enable mariadb
systemctl start mariadb
mariadb -e "CREATE DATABASE tp_linux;"
mariadb tp_linux < /root/db.sql
system restart apache2
systemctl restart apache2
php -d display_errors=1 /var/www/html/index.php
tail -n 50 /var/log/apache2/error.log
cat /var/www/html/index.php
echo "<?php phpinfo(); ?>" > /var/www/html/test.php
php -d display_errors=1 /var/www/html/index.php
tail -n 50 /var/log/apache2/error.log
cat /var/www/html/index.php
cat /var/www/html/index.php
apt install php-mysql -y
systemctl restart apache2
php -m | grep mysqli
php -d display_errors=1 /var/www/html/index.php
systemctl status mariadb --no-pagar
apt install mariadb-server mariadb-client -y
systemctl enable mariadb
systemctl start mariadb
mariadb -e "SHOW DATABASES;"
mariadb -e "SHOW TABLES;" nombre_base
cat /root/db.sql
mariadb ingenieria -e "SHOW TABLES;"
mariadb ingenieria -e "SELECT * FROM alumnos;"
lsblk
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /deb/sdc1
mkfs.ext4 /deb/sdc2
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
blkid /dev/sdc1
blkid /dev/sdc2
cat /proc/partitions > /opt/particion
cat /opt/particion
nano /etc/fstab
umount /www_dir
umount /backup_dir
mount -a
systemctl daemon-reload
mount -a
blkid
nano /etc/fstab
systemctl daemon-reload
mount -a
nano /etc/fstab
systemctl daemon-reload
mount -a
df -h
cp /root/index.php /www_dir/
ls -l /www_dir
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
systemctl restart apache2
systemctl status apache2 --no-pager
mv /var/www/html/index.php /var/www/html/index.php.old
lsmod | grep vbox
apt install virtualbox-guest-utils virtualbox-guest-x11 virtualbox-guest-dkms -y
lsmod | grep vbox
apt search virtualbox-guest
reboot
pwd
mkdir -p /opt/scripts
nano /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
cat /opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /www_dir /backup_dir
crontab -l
crontab -e
crontab -l
